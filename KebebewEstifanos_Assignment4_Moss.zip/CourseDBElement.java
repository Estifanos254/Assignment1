public class CourseDBElement implements Comparable<CourseDBElement> {
    private String ID;
    private int CRN;
    private int numCredits;
    private String roomNum;
    private String instructorName;

    public CourseDBElement(String courseId, int crn, int numCredits, String roomNum, String instructorName) {
        this.ID = courseId;
        this.CRN = crn;
        this.numCredits = numCredits;
        this.roomNum = roomNum;
        this.instructorName = instructorName;
    }

    public String getID() {
        return ID;
    }

    public int getCRN() {
        return CRN;
    }

    public int getNumOfCredits() {
        return numCredits;
    }

    public String getRoomNum() {
        return roomNum;
    }

    public String getInstructorName() {
        return instructorName;
    }

    public void setID(String courseId) {
        this.ID = courseId;
    }

    public void setCRN(int crn) {
        this.CRN = crn;
    }

    public void setNumCredits(int numCredits) {
        this.numCredits = numCredits;
    }

    public void setRoomNum(String roomNum) {
        this.roomNum = roomNum;
    }

    public void setInstructorName(String instructorName) {
        this.instructorName = instructorName;
    }

    @Override
    public int compareTo(CourseDBElement other) {
        return Integer.compare(CRN, other.getCRN());
    }

    @Override
    public String toString() {
        return "\nCourse:" + ID +
                " CRN:" + CRN +
                " Credits:" + numCredits +
                " Instructor:" + instructorName +
                " Room:" + roomNum;
    }
}