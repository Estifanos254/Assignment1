import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class CourseDBManager implements CourseDBManagerInterface {
	
	private CourseDBStructure cds;
	
	public CourseDBManager() {
		cds = new CourseDBStructure(500);
	}

	@Override
	public void add(String id, int crn, int credits, String roomNum, String instructor) {
		CourseDBElement cde = new CourseDBElement(id, crn, credits, roomNum, instructor);
		cds.add(cde);
	}

	@Override
	public CourseDBElement get(int crn) {
		CourseDBElement courseDBElement = null;
		try {
			courseDBElement = cds.get(crn);
		} catch (IOException e) {
			e.printStackTrace();
		}
		return courseDBElement;
	}

	@Override
    public void readFile(File input) throws FileNotFoundException {
        PrintWriter writer = new PrintWriter("invalid_entries.txt");
        Scanner scanner = new Scanner(input);
        String line;
        String[] course;

        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            if (line.startsWith("#")) {
                continue;
            }
            try {
                course = line.trim().split(" ", 5);
                if (course.length != 5) {
                    throw new NumberFormatException();
                }
                String courseID = course[0];
                if (courseID.isEmpty()) {
                    throw new NumberFormatException();
                }
                int crn = Integer.parseInt(course[1]);
                if (crn < 0) {
                    throw new NumberFormatException();
                }
                int credit = Integer.parseInt(course[2]);
                if (credit < 0) {
                    throw new NumberFormatException();
                }
                String roomNum = course[3];
                if (roomNum.isEmpty()) {
                    throw new NumberFormatException();
                }
                String instructor = course[4];
                if (instructor.isEmpty()) {
                    throw new NumberFormatException();
                }
                CourseDBElement cde = new CourseDBElement(courseID, crn, credit, roomNum, instructor);
                cds.add(cde);
            } catch (NumberFormatException e) {
                writer.write(line + "\n");
            }
        }
        writer.close();
        scanner.close();
    }

	@Override
	public ArrayList<String> showAll() {
		ArrayList<String> list = new ArrayList<String>();
		for (String cde : cds.showAll()) {
			list.add(cde);
		}
		return list;
	}

	@Override
	public Object getEntry(String string) {
		Object obj = null;
		try {
			obj = cds.get(string.hashCode());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return obj;
	}

}
