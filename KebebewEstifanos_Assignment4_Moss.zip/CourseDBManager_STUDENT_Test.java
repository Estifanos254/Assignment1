/*
 * @author EKebebew
 */
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.DuplicateFormatFlagsException;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CourseDBManager_STUDENT_Test {
	private CourseDBManagerInterface dataMgr;

	@BeforeEach
	void setUp() throws Exception {
		dataMgr = new CourseDBManager();
	}

	@AfterEach
	void tearDown() throws Exception {
		dataMgr = null;
	}

	@Test
	void testAddToDB() {
		try {
			dataMgr.add("CMSC203",30504,4,"SC450","Joey Bag-O-Donuts");
			dataMgr.add("CMSC203",30503,4,"SC450","Jill B. Who-Dunit");
			dataMgr.add("CMSC204",30559,4,"SC450","BillyBob Jones");
			ArrayList<String> list = dataMgr.showAll();
			assertEquals(list.get(0),"\nCourse:CMSC204 CRN:30559 Credits:4 Instructor:BillyBob Jones Room:SC450");// was "Course:CMSC204 CRN:30559 Credits:4 Instructor:BillyBob Jones Room:SC450"
			assertEquals(list.get(1),"\nCourse:CMSC203 CRN:30503 Credits:4 Instructor:Jill B. Who-Dunit Room:SC450");
			assertEquals(list.get(2),"\nCourse:CMSC203 CRN:30504 Credits:4 Instructor:Joey Bag-O-Donuts Room:SC450");
		} catch (Exception e) {// 
			fail("Unexpected exception: " + e.getMessage());
		}
	}

	@Test
	void testGet() {
		try {
			dataMgr.add("CMSC203",30504,4,"SC450","Joey Bag-O-Donuts");
			CourseDBElement c = dataMgr.get(30504);
			assertNotNull(c, "Course should not be null.");
			assertEquals("CMSC203", c.getID());
			assertEquals(30504, c.getCRN());
			assertEquals(4, c.getNumOfCredits());
			assertEquals("SC450", c.getRoomNum());
			assertEquals("Joey Bag-O-Donuts", c.getInstructorName());
		} catch (Exception e) {
			fail("Unexpected exception: " + e.getMessage());
		}
	}

	@Test
	void testGetNonexistentCRN() {
		try {
			dataMgr.add("CMSC203",30504,4,"SC450","Joey Bag-O-Donuts");
			CourseDBElement c = dataMgr.get(12345);
			assertNull(c, "Course should be null.");
		} catch (Exception e) {
			fail("Unexpected exception: " + e.getMessage());
		}
	}

	/**
	 * Test for the read method
	 */
	@Test
	public void testRead() {
	    try {
	        // Create a temporary file
	        File inputFile = File.createTempFile("temp", null);
	        inputFile.deleteOnExit();

	        // Write test data to the file
	        PrintWriter writer = new PrintWriter(inputFile);
	        writer.println("CMSC203 30504 4 SC450 Joey Bag-O-Donuts");
	        writer.println("CMSC204 30503 4 SC450 Jill B. Who-Dunit");
	        writer.close();

	        // Read the file and check that the courses were added to the database
	        dataMgr.readFile(inputFile);
	        CourseDBElement course1 = dataMgr.get(30504);
	        CourseDBElement course2 = dataMgr.get(30503);
	        assertNotNull(course1);
	        assertNotNull(course2);
	        assertEquals("CMSC203", course1.getID());
	        assertEquals(30504, course1.getCRN());
	        assertEquals(4, course1.getNumOfCredits());
	        assertEquals("SC450", course1.getRoomNum());
	        assertEquals("Joey Bag-O-Donuts", course1.getInstructorName());
	        assertEquals("CMSC204", course2.getID());
	        assertEquals(30503, course2.getCRN());
	        assertEquals(4, course2.getNumOfCredits());
	        assertEquals("SC450", course2.getRoomNum());
	        assertEquals("Jill B. Who-Dunit", course2.getInstructorName());
	    } catch (Exception e) {
	        fail("Should not have thrown an exception");
	    }
	}
}
