import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

public class CourseDBStructure implements CourseDBStructureInterface {
    private LinkedList<CourseDBElement>[] hashTable;
    private int tableSize;

    public CourseDBStructure(int n) {
        tableSize = getNext4K3Prime((int)(n/1.5));
        hashTable = new LinkedList[tableSize];
        for (int i = 0; i < tableSize; i++) {
            hashTable[i] = new LinkedList<CourseDBElement>();
        }
    }

    public CourseDBStructure(String testing, int tableSize) {
        this.tableSize = tableSize;
        hashTable = new LinkedList[tableSize];
        for (int i = 0; i < tableSize; i++) {
            hashTable[i] = new LinkedList<CourseDBElement>();
        }
    }

    @Override
    public void add(CourseDBElement element) {
    	
        int hashCode = Integer.toString(element.getCRN()).hashCode();
        int index = hashCode % tableSize;

        LinkedList<CourseDBElement> bucket = hashTable[index];

        for (CourseDBElement e : bucket) {
            if (e.getCRN() == element.getCRN()) {
            	e.setID(element.getID());
            	e.setInstructorName(element.getInstructorName());
            	e.setNumCredits(element.getNumOfCredits());
            	e.setRoomNum(element.getRoomNum());
                return; // exit quietly if the element already exists
            }
        }

        bucket.add(element);
    }

    @Override
    public CourseDBElement get(int crn) throws IOException {
        int hashCode = Integer.toString(crn).hashCode();
        int index = hashCode % tableSize;

        LinkedList<CourseDBElement> bucket = hashTable[index];

        for (CourseDBElement e : bucket) {
            if (e.getCRN() == crn) {
                return e; // return the element if found
            }
        }

        throw new IOException("Course with CRN " + crn + " not found."); // throw an IOException if not found
    }

    @Override
    public ArrayList<String> showAll() {
        ArrayList<String> result = new ArrayList<String>();

        for (LinkedList<CourseDBElement> bucket : hashTable) {
            for (CourseDBElement element : bucket) {
                result.add(element.toString());
            }
        }

        return result;
    }

    @Override
    public int getTableSize() {
        return tableSize;
    }

    @Override
    public Iterator<String> iterator() {
        ArrayList<String> list = showAll();
        return list.iterator();
    }

    // helper method to find the next prime number greater than or equal to n
    private int getNext4K3Prime(int n) {
        while (!isPrime(n) || (n-3)%4!=0) {
            n++;
        }

        return n;
    }

    // helper method to check if a number is prime
    private boolean isPrime(int n) {
        if (n < 2) {
            return false;
        }

        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) {
                return false;
            }
        }

        return true;
    }
}
